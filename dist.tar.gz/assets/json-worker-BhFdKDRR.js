import"./monaco-editor-D6KFlyNG.js";
